const startButton = document.getElementById("start");

startButton.onclick = () => {
    location.href = "game.html";
}