import CreateDraggableForm from "./forms/CreatableForm/CreateDraggableForm"

const Layout = () => {
  return (
    <div>
        <CreateDraggableForm/>
    </div>
  )
}

export default Layout